jQuery( function($){
	
	$( document ).ready( function() {
		
	});
	
	$(window).load(function() {
		
	});
	
});