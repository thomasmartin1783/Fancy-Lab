	<footer>
		<p>This is another paragraph...</p>
	</footer>
</body>
</html>