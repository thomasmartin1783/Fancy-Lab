<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Learn WP</title>
</head>
<body>
	<p>This is just a paragraph!</p>
</body>
</html>