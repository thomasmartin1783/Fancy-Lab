<?php get_header(); ?>
	<div class="content-area">
		<main>
			<section class="slide"></section>
			<section class="services"></section>
			<section class="middle-area">
				<aside class="sidebar"></aside>
				<div class="news"></div>
			</section>
			<section class="map"></section>
		</main>
	</div>
<?php get_footer(); ?>