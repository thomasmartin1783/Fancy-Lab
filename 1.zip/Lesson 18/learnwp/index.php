<?php get_header(); ?>
	<div class="content-area">
		<main>
			<section class="slide">Slide</section>
			<section class="services">Services</section>
			<section class="middle-area">
				<aside class="sidebar">Sidebar</aside>
				<div class="news">News</div>
			</section>
			<section class="map">Map</section>
		</main>
	</div>
<?php get_footer(); ?>