	<footer>
		<p>This is another paragraph...</p>
	</footer>
<?php wp_footer(); ?>
</body>
</html>